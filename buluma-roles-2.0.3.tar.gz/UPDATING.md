# Updating the roles

1. Delete the roles:

```shell
rm -Rf roles/*
```

2. Copy the roles in:

```shell
./UPDATING.sh
```

3. Update galaxy.yml

Bump version.
